# ⬡ AWS CloudOps Lab — Student Project Portal

> **Hands-on AWS Cloud Architecture & DevOps Engineering projects** — CI/CD, Containers, Kubernetes, IaC, and Observability. Submit solutions via GitHub Pull Request.

[![GitHub Stars](https://img.shields.io/github/stars/your-org/aws-cloudops-lab?style=flat-square)](https://github.com/your-org/aws-cloudops-lab)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](CONTRIBUTING.md)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg?style=flat-square)](LICENSE)

---

## 🌐 Project Portal

**[→ Open the Interactive Project Portal](https://your-org.github.io/aws-cloudops-lab)**

The portal lists all 12 projects, shows starter code, architecture diagrams, and guides you through GitHub submission.

---

## 📚 Projects Overview

| # | Project | Track | Difficulty | Time |
|---|---------|-------|------------|------|
| 01 | Multi-Stage CI/CD Pipeline with CodePipeline | CI/CD | ⚡ Intermediate | 8–12 hrs |
| 02 | Containerize & Deploy with ECS Fargate | Containers | 🟢 Beginner | 6–8 hrs |
| 03 | Kubernetes Cluster on EKS with Helm | Kubernetes | 🔴 Advanced | 14–20 hrs |
| 04 | Infrastructure as Code with Terraform | IaC | ⚡ Intermediate | 10–14 hrs |
| 05 | GitOps with ArgoCD on EKS | Kubernetes | 🔴 Advanced | 12–16 hrs |
| 06 | Serverless CI/CD with Lambda & SAM | CI/CD | 🟢 Beginner | 6–8 hrs |
| 07 | Observability: CloudWatch + Grafana | Monitoring | ⚡ Intermediate | 10–12 hrs |
| 08 | AWS Security Hardening & Compliance | IaC | 🔴 Advanced | 12–16 hrs |
| 09 | Multi-Region Active-Active with Route 53 | IaC | 🔴 Advanced | 16–20 hrs |
| 10 | Microservices with AWS App Mesh | Kubernetes | 🔴 Advanced | 14–18 hrs |
| 11 | Cost Optimization & FinOps Dashboard | Monitoring | 🟢 Beginner | 6–8 hrs |
| 12 | Event-Driven Architecture (SQS/SNS/EventBridge) | CI/CD | ⚡ Intermediate | 8–10 hrs |

---

## 🗂 Repository Structure

```
aws-cloudops-lab/
├── index.html                        ← GitHub Pages portal (open this!)
├── README.md
├── CONTRIBUTING.md
├── .github/
│   ├── PULL_REQUEST_TEMPLATE.md      ← Auto-loaded on every PR
│   └── workflows/
│       └── validate-submission.yml   ← CI checks on student PRs
├── projects/
│   ├── 01-cicd-codepipeline/
│   │   ├── README.md                 ← Full requirements & rubric
│   │   └── starter/                  ← Starter code / templates
│   ├── 02-ecs-fargate/
│   ├── 03-eks-helm/
│   └── ... (12 total)
└── solutions/
    ├── 01-cicd-codepipeline/
    │   └── student-github-username/  ← Each student's solution here
    │       ├── README.md
    │       └── src/
    └── ... 
```

---

## 🚀 How to Submit

### Step 1 — Fork this Repository
Click **Fork** at the top right of this page.

### Step 2 — Clone Your Fork
```bash
git clone https://github.com/YOUR-USERNAME/aws-cloudops-lab
cd aws-cloudops-lab
```

### Step 3 — Create a Branch
```bash
# Replace N with project number, YOUR-NAME with your name
git checkout -b solution/project-N-YOUR-NAME
```

### Step 4 — Build Your Solution
Place all files under:
```
solutions/0N-project-name/YOUR-GITHUB-USERNAME/
```

Your folder **must include** a `README.md` with:
- Architecture diagram (screenshot or draw.io export)
- Setup/deployment steps
- Screenshots proving it works
- Challenges and lessons learned
- Approximate AWS cost + cleanup steps

### Step 5 — Submit a Pull Request
```bash
git add .
git commit -m "solution(project-N): YOUR-NAME solution"
git push origin solution/project-N-YOUR-NAME
```
Then go to GitHub → **Compare & pull request**. The PR template loads automatically.

---

## 📋 Evaluation Rubric

Each project is scored out of **100 points**:

| Criterion | Points |
|-----------|--------|
| All objectives completed | 40 |
| Code quality & structure | 20 |
| Architecture writeup & diagram | 20 |
| Security & cost awareness | 10 |
| Innovation / going beyond requirements | 10 |

---

## 🛠 Prerequisites

Before starting, ensure you have:

- **AWS Account** (free tier works for most beginner projects)
- **AWS CLI v2** configured: `aws configure sso`
- **Git** + **GitHub account**
- **Docker Desktop** (for container projects)
- **kubectl** + **eksctl** (for Kubernetes projects)
- **Terraform ≥ 1.6** (for IaC projects)
- **AWS SAM CLI** (for serverless projects)

### Recommended VS Code Extensions
- AWS Toolkit
- HashiCorp Terraform
- Kubernetes (ms-kubernetes-tools)
- YAML

---

## 🏅 Leaderboard

Top submissions are featured on the portal leaderboard. Points:
- 🟢 Beginner project: **50 pts**
- ⚡ Intermediate project: **100 pts**
- 🔴 Advanced project: **150 pts**
- First submission bonus: **+30 pts**
- Peer review (review another student's PR): **+10 pts**

---

## 🤝 Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines on improving project requirements, adding new projects, or fixing issues.

---

## ⚠️ Cost Warning

Some projects (EKS, Multi-Region) can incur AWS costs. Always:
1. Use the **AWS Free Tier** where possible
2. **Destroy resources** after completion (`terraform destroy`, delete EKS clusters)
3. Set **AWS Budgets alerts** at $5 and $20
4. Check [infracost.io](https://www.infracost.io) before deploying

---

## 📄 License

MIT — See [LICENSE](LICENSE)
